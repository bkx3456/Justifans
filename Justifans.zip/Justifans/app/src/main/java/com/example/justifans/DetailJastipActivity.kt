package com.example.justifans

class DetailJastipActivity {

}