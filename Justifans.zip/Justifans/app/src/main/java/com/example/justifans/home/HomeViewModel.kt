package com.example.justifans.home

class HomeViewModel {
}